<?php
//error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR);
$session['id']=session_id();
$session['userid']=$userid;
//echo $session['userid'];
?>