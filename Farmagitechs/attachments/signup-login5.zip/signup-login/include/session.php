<?php
session_start();
session_register("session");
?>